Packaging quick reminder
========================

Make sure maintainer dependencies are installed::

    pip install -e .[maintainer,dev]

Run release commad and follow prompt instuctions::

    fullrelease
